#! /bin/sh

killall shellinaboxd
rm -rf /koolshare/init.d/*shellinabox*
rm -rf /koolshare/shellinabox
rm -rf /koolshare/res/icon-shellinabox.png
rm -rf /koolsahre/scripts/shellinabox_config.sh
rm -rf /koolsahre/scripts/uninstall_shellinabox.sh
rm -rf /koolsahre/webs/Module_shellinabox_config.asp
